/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LCD1602_I2C.h"
#include "oximeter.h"
#include "keypad.h"
#include "panel.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* ---- Sampling and stability parameters; tune them here only ---- */
#define POLL_MS 	 250u /* Polling period. The module refreshes its
 	 	 	 	 	 	   * data every 4 s, so reading faster just
 	 	 	 	 	 	   * re-reads the same value - harmless, and it
 	 	 	 	 	 	   * notices a finger within 0.25 s */
#define HIST_N 			5 /* history length used for the stability test */
#define HR_SPREAD_MAX  12 /* spread over 5 readings above which the
 	 	 	 	 	 	   * value is considered not settled yet (bpm) */
#define LOST_GRACE 	   12 /* invalid ticks before the finger counts as
 	 	 	 	 	       * removed (250 ms x 12 = 3 s) */

/* ---- Power-on PIN ---- */
#define PASSWORD   "1234" /* change the PIN on this line only */
#define PIN_LEN 		4 /* must match the length of PASSWORD */
#define PIN_SCAN_MS 	8u /* keypad polling; debouncing lives in keypad.c */
#define PIN_WRONG_HOLD 1500u /* how long the "wrong PIN" message stays */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* Pad a line out to 16 characters.
 * The LCD never clears itself: after "HR 100" a shorter "HR 72" would leave
 * the stray 0 on screen. Padding beats calling lcd_clear() every time, which
 * produces a visible flicker. */
static void pad16(char *s) {
	size_t n = strlen(s);
	while (n < 16u) {
		s[n++] = ' ';
	}
	s[16] = '\0';
}
/* ==========================================================================
 * Stability filtering
 *
 * A single reading cannot be trusted. Just after a finger is placed, or with
 * the wrong contact pressure, or on a weak signal, the module's algorithm
 * counts the dicrotic notch of the pulse waveform as a second beat and
 * reports exactly twice the true rate - 70 shows up as 140. This is the
 * classic PPG doubling artefact.
 *
 * A range check cannot catch it: 140 is perfectly physiological. What does
 * catch it is agreement between consecutive readings - the artefact comes
 * and goes, while a real heart rate settles into a narrow band.
 * ========================================================================== */
typedef struct {
	int32_t buf[HIST_N];
	uint8_t cnt; /* how many samples are filled in */
	uint8_t idx; /* ring buffer write index */
} Hist;
static Hist s_hr_hist;
static int32_t s_hr_shown = -1; /* heart rate on display, -1 = none yet */
static int32_t s_spo2_shown = -1; /* likewise for SpO2 */
static uint16_t s_lost = 0; /* consecutive invalid readings */
static void hist_reset(Hist *h) {
	h->cnt = 0;
	h->idx = 0;
}
static void hist_push(Hist *h, int32_t v) {
	h->buf[h->idx] = v;
	h->idx = (uint8_t) ((h->idx + 1u) % HIST_N);
	if (h->cnt < HIST_N) {
		h->cnt++;
	}
}
/* Full history and spread within the limit -> return the median,
 * otherwise -1 meaning "not settled yet". */
static int32_t hist_stable(const Hist *h, int32_t spread_max) {
	int32_t t[HIST_N];
	uint8_t i, j;
	if (h->cnt < HIST_N) {
		return -1;
	}
	for (i = 0; i < HIST_N; i++) {
		t[i] = h->buf[i];
	}
	for (i = 1; i < HIST_N; i++) { /* insertion sort, N=5 */
		int32_t k = t[i];
		j = i;
		while (j > 0u && t[j - 1] > k) {
			t[j] = t[j - 1];
			j--;
		}
		t[j] = k;
	}
	if ((t[HIST_N - 1] - t[0]) > spread_max) {
		return -1;
	}
	return t[HIST_N / 2]; /* median */
}
/* Display state. Three of them, not two:
 * ST_NO_FINGER nothing readable -> ask for a finger
 * ST_MEASURING data but unsettled -> ask the user to hold still; this is
 * where a 140 artefact gets held back
 * ST_SHOW settled -> show the numbers
 */
typedef enum {
	ST_NO_FINGER, ST_MEASURING, ST_SHOW
} DispState;
static DispState hr_step(int32_t raw_hr, int32_t raw_spo2) {
	if (raw_hr <= 0) {
		s_lost++;
		if (s_lost > LOST_GRACE) { /* the finger really is gone */
			hist_reset(&s_hr_hist);
			s_hr_shown = -1;
			s_spo2_shown = -1;
			return ST_NO_FINGER;
		}
		/* Inside the grace period keep the previous reading on screen so
		 * the display does not flip back and forth. */
		if (s_hr_shown > 0) {
			return ST_SHOW;
		}
		if (s_hr_hist.cnt > 0) {
			return ST_MEASURING;
		}
		return ST_NO_FINGER; /* never read anything at all */
	}
	s_lost = 0;
	hist_push(&s_hr_hist, raw_hr);
	{
		int32_t v = hist_stable(&s_hr_hist, HR_SPREAD_MAX);
		if (v > 0) {
			s_hr_shown = v;
			if (raw_spo2 > 0) {
				s_spo2_shown = raw_spo2;
			}
			return ST_SHOW;
		}
	}
	if (s_hr_shown > 0) {
		return ST_SHOW;
	} /* settled already, one bad tick */
	return ST_MEASURING;
}
/* Lay out the two display lines, each exactly 16 characters */
static void build_lines(DispState st, uint8_t comm_ok, float temp, uint8_t spin,
		char *l1, char *l2) {
	static const char *dots[4] = { " ", ". ", ".. ", "..." };
	if (!comm_ok) {
		strcpy(l1, "Sensor offline");
		strcpy(l2, "Check wiring");
	} else if (st == ST_NO_FINGER) {
		snprintf(l1, 17, "Place finger%s", dots[spin & 3u]);
		snprintf(l2, 17, "Board %4.1f degC", (double) temp);
	} else if (st == ST_MEASURING) {
		snprintf(l1, 17, "Measuring%s", dots[spin & 3u]);
		strcpy(l2, "Hold still");
	} else {
		/* SP/HR OUTPUTS BE HERE */
		int sp =
				(s_spo2_shown > 0 && s_spo2_shown <= 100) ?
						(int) s_spo2_shown : 0;
		int hr = (s_hr_shown > 0 && s_hr_shown <= 999) ? (int) s_hr_shown : 0;
		snprintf(l1, 17, "SpO2%3d%% HR%3d", sp, hr);
		snprintf(l2, 17, "Temp %4.1f degC", (double) temp);
	}
	pad16(l1);
	pad16(l2);
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
// ENUM ZONE ENUM ZONE ENUM ZONE ENUM ZONE //
/* App display modes enum, real*/
typedef enum {
		//APP_WAIT_START,
		APP_NO_FINGER_WARNING,
		APP_MONITORING,
		APP_ALERT,
		APP_MENU,
		APP_STAT,
		APP_PATIENT_INFO,
		APP_ADDRESS,
		APP_CPR
	} AppState;

/* Event flag enum*/	
typedef enum {
	    EVENT_NONE = 0u,
	    EVENT_IRREGULAR = 1u << 0u,
		EVENT_MANUAL = 1u << 1u
	} EventFlags;

/* CPR phase enum*/
typedef enum {
	CPR_COMPRESS,
	CPR_RELAX,
	CPR_BREATHE,
} CPRPhase;


// VARIABLE ZONE VARIABLE ZONE VARIABLE ZONE VARIABLE ZONE //
static uint32_t cpr_phase_start_ms = 0;
static CPRPhase cpr_phase = CPR_COMPRESS;
static uint8_t cpr_screen_index = 0;
static uint32_t cpr_screen_switch_ms = 0;
static uint8_t cpr_breath_screen_active = 0;
static uint8_t cpr_compressions_since_breath = 0u;

static const char *cpr_screen_text[6] = {
	"COMPRESS IN TIME"
	"WITH LIGHTS",
	"CALL 000 IF CPR",
	"NEEDED",
	"PRESS # TO GO",
	"BACK"
};
static const char cpr_breath_screen_text1[17] = "BREATHE 2 RESCUE";
static const char cpr_breath_screen_text2[17] = "BREATHS         ";
static const char monitor_line_1[17] = "All Clear       ";
static const char monitor_line_2[17] = "System Idle...  ";
static const char warning_line_1[17] = "No Finger Found ";
static const char warning_line_2[17] = "Place on Finger ";
static const char menu_line_1[17] = "1.STAT 2.P.INFO ";
static const char menu_line_2[17] = "3.ADDR 4.CPR    ";
static const char patient_name[17] = "Stanley Leichter";
static const char patient_age[17] = "         AGE: 68";
static const char address_line_1[17] = "Bldg 420, 3 Kent";
static const char address_line_2[17] = "St, Bentley     "
static uint32_t time_at_last_readms = 0;
static const uint32_t OXIMETER_POLL_DELAYms = 10;
static char prev1[17] = "                ";
static char prev2[17] = "                ";
static const char alert_line_1[17] = "EMERGENCY! ENTER";
static const char alert_line_2[17] = "AND ASSIST!     ";
static uint8_t stat_message_index = 0;
static const char stat_manual[17] = "MANUAL ACTIVATED";
static const char stat_heart[17] = "PULSE UNUSUAL   ";

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/* ==========================================================================
 * Power-on PIN
 *
 * Blocking by design: nothing proceeds until the PIN is accepted, so a plain
 * loop is enough and no state machine is needed. It runs once per power-up;
 * after that the main loop never touches the keypad again.
 * ========================================================================== */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
// THE FUNCTIONS FUNCTION THE FUNCTIONS FUNCTION //
static void wait_for_start(void) {
	for (;;) {
		char key = Keypad_Scan();
		if (key == '1') {
		return;
		}

		HAL_Delay(PIN_SCAN_MS);
	}
}

static bool time_to_read_oximeter(uint32_t now_time) {
	if (now_time - time_at_last_readms == OXIMETER_POLL_DELAYms) {
		time_at_last_readms = now_time;
		return true;
	}
	else {
		return false;
	}
}

static bool accident_detected(OxiReading reading) {
	if (reading.heartbeat > 100 || reading.heartbeat < 55) {
		event_flags |= EVENT_IRREGULAR;
	}
	return (event_flags != EVENT_NONE);
}

static void clear_event_codes(void) {
	event_flags = EVENT_NONE;
}

static void cpr_leds(uint8_t on) {
	Panel_SetLed(2, on);
	Panel_SetLed(3, on);
}

static void stat_builder(char *l1) {
	int sp02 = (s_spo2_show > 0 && s_spo2_shown <= 100) ?
				(int) s_spo2_shown : 0;
	int hr = (s_hr_shown > 0 && s_hr_shown <= 999) ? (int) s_hr_shown : 0;
	snprintf(l1, 17, "SpO2%3d%% HR%3d", sp02, hr);
	pad16(l1);
}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/* Functions for menu states, each shows information relating
* to the patient to help with their care such as their address
* their current heart rate and SpO2 and so on */
// SHOW ZONE SHOW ZONE SHOW ZONE SHOW ZONE SHOW ZONE //

static void printer_l1(char[16] fresh_line) {
	if (strncmp(prev1, fresh_line, 16) != 0) {
		lcd_put_cur(0, 0);
		lcd_send_string(fresh_line);
		strncpy(prev1, fresh_line, sizeof(prev1));
	}
}

static void printer_l2(char fresh_line) {
	if (strncmp(prev2, fresh_line, 16) != 0) {
		lcd_put_cur(1, 0);
		lcd_send_string(fresh_line);
		strncpy(prev2, fresh_line, sizeof(prev2));
	}
}

static void show_monitor(void) {
	// show monitor code
	printer_l1(monitor_line_1);
	printer_l2(monitor_line_2);
	
}

static void show_alert(void) {
	// show alert screen code
	printer_l1(alert_line_1);
	printer_l2(alert_line_2);
}

static void show_no_finger_warning(void) {
	// show no finger warning code
	printer_l1(warning_line_1);
	printer_l2(warning_line_2);
}

static void show_menu(void) {
	// show menu code
	printer_l1(menu_line_1);
	printer_l2(menu_line_2);
}

static void show_stat(char *line2, char *line2) {
	// show stat code
	stat_builder(line1);
	printer_l1(line1);
	printer_l2(line2);
}

static void show_patient_info(void) {
	// show patient info code
	printer_l1(patient_name); //Goddamn loser
	printer_l2(patient_age);
}

static void show_address(void) {
	// show address code
	// attempting to code it better
	// for loop logic worked in an external editor
	printer_l1(address_line_1);
	printer_l2(address_line_2);
}

static void show_cpr(void) {
	// show cpr code
	// Needs to change screen and flash LEDs
	// jagged array containing all three screens of text for the cpr mode
	uint32_t now_time = HAL_GetTick();

	if (cpr_breath_screen_active) {
		lcd_clear();
		lcd_put_cur(0, 0);
		lcd_send_string(cpr_breath_screen_text1);
		lcd_put_cur(1, 0);
		lcd_send_string(cpr_breath_screen_text2);
		return;
	}

	if (HAL_GetTick() - cpr_screen_switch_ms >= 4000u) {
		cpr_screen_switch_ms = HAL_GetTick();
		cpr_screen_index = (cpr_screen_index + 2u) % 6u;
	}
	// char cpr_line_1[17];
	// char cpr_line_2[17];
	// //set the lines to be printed to the lcd
	// for(int j = 0; j<16; j++){
	// 	cpr_line_1[j]=cpr_screen_text[cpr_screen_index][j];
	// 	cpr_line_2[j]=cpr_screen_text[cpr_screen_index+1][j+16];
	// }
	lcd_clear();
	lcd_put_cur(0, 0);
	lcd_send_string(cpr_screen_text[cpr_screen_index]);
	lcd_put_cur(1, 0);
	lcd_send_string(cpr_screen_text[cpr_screen_index+1]);
}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  /* USER CODE BEGIN 2 */
	/* --- LCD on I2C1 --- */
	lcd_init(&hi2c1);
	lcd_put_cur(0, 0);
	lcd_send_string("BOOT SYSTEM?    ");
	lcd_put_cur(1, 0);
	lcd_send_string("1. YES          ");
	/* --- Keypad: the PIN gate comes first ---
	 * Placed before the sensor is started, so nothing is acquired until the
	 * PIN is accepted and the sensor LEDs stay dark while unauthorised. */
	Keypad_Init();
	Panel_Init(); /* all four LEDs off; buttons live from power-up */
	/* Initial state of the four LEDs at power-up. Change a 0 to a 1 to have
	 * that LED lit from the start; Panel_SetLed(0, 1) lights LED0 so the first
	 * press of BUTTON0 turns it off.
	 * Always go through Panel_SetLed() rather than the CubeMX initial level: it
	 * updates both the pin and the internal s_leds bit, and once those two
	 * disagree the first press toggles the wrong way. */
	Panel_SetLed(0, 0);
	Panel_SetLed(1, 0);
	Panel_SetLed(2, 0);
	Panel_SetLed(3, 0);
	wait_for_start();
	lcd_put_cur(0, 0);
	lcd_send_string("BOOTING...      ");
	lcd_put_cur(1, 0);
	lcd_send_string("                ");
	HAL_Delay(1000);
	lcd_put_cur(0, 0);
	lcd_send_string("SYSTEM IDLE     ");
	lcd_put_cur(1, 0);
	lcd_send_string("ALL CLEAR       ");
	show_monitor();
	HAL_Delay(4000);

	
	/* --- Heart rate sensor on I2C3 --- */
	{
		uint8_t addr = Oxi_ScanBus(&hi2c3); /* break here; expect 0xAE */
		(void) addr;
	}
	Oxi_Start(&hi2c3); /* the module only measures after this command */
	hist_reset(&s_hr_hist);
	HAL_Delay(1000);
	AppState app_state = APP_MONITORING;
  /* USER CODE END 2 */

  /* Initialize leds */
  BSP_LED_Init(LED_GREEN);

  /* Initialize USER push-button, will be used to trigger an interrupt each time it's pressed.*/
  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_EXTI);

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  char statline1[17] = "";

 while (1)
 {

   /* USER CODE END WHILE */

   /* USER CODE BEGIN 3 */
	char key = Keypad_Scan();
	Panel_Task();

	if ((HAL_GPIO_ReadPin(BTN_PORT[0], BTN_MASK[0]) == GPIO_PIN_RESET) && app_state == APP_MONITORING) {
		event_flags |= EVENT_MANUAL;
	}



// MAIN CASE MAIN CASE MAIN CASE MAIN CASE //
	switch (app_state) {

	case APP_MONITORING:
		// Handle monitoring state
		uint32_t now_time = HAL_GetTick()
		if (event_flags != EVENT_NONE) {
			app_state = APP_MENU;
			show_alert();
			break;
		}
		if (time_to_read_oximeter()) {
			OxiReading reading;

			if (Oxi_Read(&reading) == HAL_OK) {
				accident_detected(reading);
				
				// Handle read error
			}
			else {
				app_state = APP_NO_FINGER_WARNING;
			}
		}
		show_monitor();
		break;

	case APP_NO_FINGER_WARNING:
		// Handle no finger warning state

		show_no_finger_warning();
		AppsState = APP_MONITORING;
		break;
	
		case APP_ALERT:
		// Handle alert state
		update_alert_display();
		update_alert_leds();
		handle_alert_key(key);
		break;

	case APP_MENU:
		// Handle menu state
		if (Keypad_Scan() == "1") app_state = APP_STAT;
		else if (Keypad_Scan() == "2") app_state = APP_PATIENT_INFO;
		else if (Keypad_Scan() == "3") app_state = APP_ADDRESS;
		else if (Keypad_Scan() == "4") app_state = APP_CPR;
		else {
			show_menu();
		}
		break;

	case APP_STAT:
		// Handle stat state
		if (Keypad_Scan() == '#') {
			app_state = APP_MENU;
		}
		
		const char statline2[16];
		if ((event_flags & EVENT_MANUAL) != 0u) statline2 = stat_manual;
		else if ((event_flags & EVENT_IRREGULAR) != 0u) statline2 = stat_heart;
		if (time_to_read_oximeter()) {
			OxiReading reading;
			if (Oxi_Read(&reading) == HAL_OK) {
				
				show_stat(statline2);
			}
			else {
				show_no_finger_warning();
			}
		}
		break;

	case APP_PATIENT_INFO:
		// Handle patient info state
		if (Keypad_Scan() == '#') {
			app_state = APP_MENU;
		}
		else {
			show_patient_info();
		}
		break;

	case APP_ADDRESS:
		// Handle address state
		if (Keypad_Scan() == '#') {
			app_state = APP_MENU;
		}
		else {
			show_address();
		}
		break;

	case APP_CPR:
		// Handle CPR state
		uint32_t now_time = HAL_GetTick();

		if (Keypad_Scan() == '#') {
			app_state = APP_MENU;
			break;
		}
		switch (cpr_phase) {
			case CPR_COMPRESS:
				if (now_time - cpr_phase_start_ms >= 450u) {
					cpr_leds(0);
					cpr_phase = CPR_RELAX;
					cpr_phase_start_ms = now_time;
					cpr_compressions_since_breath++;
					if (cpr_compressions_since_breath >= 5u) {
						cpr_phase = CPR_BREATH;
						cpr_phase_start_ms = now_time;
						cpr_breath_screen_active = 1u;
						cpr_compressions_since_breath = 0u;
					}
				}
				else {
					cpr_leds(1);
				}
				break;
			
			case CPR_RELAX:
				if (now_time - cpr_phase_start_ms >= 150u) {
					cpr_phase = CPR_COMPRESS;
					cpr_phase_start_ms = now_time;
				}
				else {
					cpr_leds(0);
				}
				break;

			case CPR_BREATHE:
				if (now_time - cpr_phase_start_ms >= 2500u) {
					cpr_phase = CPR_COMPRESS;
					cpr_phase_start_ms = now_time;
					cpr_breath_screen_active = 0u;
					cpr_screen_switch_ms = now_time;
				}
				else {
					cpr_set_leds(1);
				}
				break;
		}
		show_cpr();
		break;
	}

//  /* USER CODE END 3 */
	}
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
